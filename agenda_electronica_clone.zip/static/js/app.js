const $ = (q, el=document) => el.querySelector(q);
const $$ = (q, el=document) => Array.from(el.querySelectorAll(q));

const STATE = {
  pages: ["home","agenda","dosar","absente","reusita"],
  current: "home",
};

function requireAuth(){
  if(localStorage.getItem("ae_logged_in") !== "1"){
    window.location.href = "index.html";
    return false;
  }
  return true;
}

function setDisplayName(){
  const dn = localStorage.getItem("ae_display_name") || "LUNGU ANDREEA";
  $("#displayNameTop").textContent = dn;
  $("#displayNameSide").textContent = dn;
}

function toggleSidebar(){
  $("#sidebar").classList.toggle("expanded");
}

function closeUserMenu(){
  $("#userMenu").classList.add("hidden");
}

function toggleUserMenu(){
  $("#userMenu").classList.toggle("hidden");
}

function navigate(page){
  if(!STATE.pages.includes(page)) page = "home";
  STATE.current = page;

  // show correct view
  $$(".view").forEach(v => v.classList.add("hidden"));
  $("#view-"+page).classList.remove("hidden");

  // set active tile
  $$(".tile").forEach(t => t.classList.remove("active"));
  const active = $(`.tile[data-page="${page}"]`);
  if(active) active.classList.add("active");

  // set hash
  const desired = "#"+page;
  if(window.location.hash !== desired){
    history.replaceState(null, "", desired);
  }

  closeUserMenu();
  // on mobile: keep sidebar as is (no auto close) – user asked like original
}

function initRoutes(){
  const hash = (window.location.hash || "").replace("#","");
  if(hash) navigate(hash);
  else navigate("home");
  window.addEventListener("hashchange", () => {
    const h = (window.location.hash || "").replace("#","");
    if(h) navigate(h);
  });
}

function logout(){
  localStorage.removeItem("ae_logged_in");
  localStorage.removeItem("ae_role");
  window.location.href = "index.html";
}

document.addEventListener("DOMContentLoaded", () => {
  if(!requireAuth()) return;
  setDisplayName();

  // Sidebar toggle
  $("#hamburger").addEventListener("click", toggleSidebar);

  // Brand clicks go home
  $("#brandTop").addEventListener("click", () => navigate("home"));
  $("#brandSide").addEventListener("click", () => navigate("home"));

  // Tiles
  $$(".tile").forEach(t => {
    t.addEventListener("click", () => navigate(t.dataset.page));
  });

  // User dropdown
  $("#userPill").addEventListener("click", (e) => {
    e.stopPropagation();
    toggleUserMenu();
  });
  document.addEventListener("click", () => closeUserMenu());
  $("#btnProfile").addEventListener("click", () => navigate("dosar"));
  $("#btnLogout").addEventListener("click", logout);

  // Esc closes menu
  document.addEventListener("keydown", (e) => {
    if(e.key === "Escape") closeUserMenu();
  });

  initRoutes();
});
