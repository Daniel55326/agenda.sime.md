const $ = (q, el=document) => el.querySelector(q);

function openModal(role){
  const backdrop = $("#modalBackdrop");
  backdrop.classList.remove("hidden");
  $("#authRole").textContent = role === "parinte" ? "Autentificare părinte" : "Autentificare elev";
  $("#username").value = "";
  $("#password").value = "";
  $("#username").focus();
  backdrop.dataset.role = role;
}

function closeModal(){
  $("#modalBackdrop").classList.add("hidden");
}

function login(){
  // NOTE: demo - accept orice username/password
  const role = $("#modalBackdrop").dataset.role || "elev";
  localStorage.setItem("ae_logged_in", "1");
  localStorage.setItem("ae_role", role);
  // nume fix (cum ai cerut)
  localStorage.setItem("ae_display_name", "LUNGU ANDREEA");
  window.location.href = "app.html#dosar"; // intra direct pe dashboard; poti schimba in #home
}

document.addEventListener("DOMContentLoaded", () => {
  $("#btnParinte").addEventListener("click", () => openModal("parinte"));
  $("#btnElev").addEventListener("click", () => openModal("elev"));

  $("#closeModal").addEventListener("click", closeModal);
  $("#modalBackdrop").addEventListener("click", (e) => {
    if(e.target.id === "modalBackdrop") closeModal();
  });

  $("#loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    login();
  });

  document.addEventListener("keydown", (e) => {
    if(e.key === "Escape") closeModal();
  });

  // if already logged in
  if(localStorage.getItem("ae_logged_in") === "1"){
    // optional: auto redirect
    // window.location.href = "app.html";
  }
});
