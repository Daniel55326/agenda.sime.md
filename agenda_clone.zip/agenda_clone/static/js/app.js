(() => {
  const backdrop = document.getElementById('loginBackdrop');
  const roleTitle = document.getElementById('loginRoleTitle');
  const toTop = document.querySelector('.to-top');

  const open = (role) => {
    roleTitle.textContent = role === 'parinte' ? 'Autentificare părinte' : 'Autentificare elev';
    backdrop.hidden = false;
    document.body.style.overflow = 'hidden';
    // focus first input
    const first = backdrop.querySelector('input');
    if (first) setTimeout(() => first.focus(), 50);
  };

  const close = () => {
    backdrop.hidden = true;
    document.body.style.overflow = '';
  };

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-open-login]');
    if (btn) {
      open(btn.getAttribute('data-open-login'));
      return;
    }

    if (e.target.matches('[data-close]')) {
      close();
      return;
    }

    // click outside modal closes
    if (!backdrop.hidden && e.target === backdrop) {
      close();
      return;
    }

    if (e.target === toTop) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !backdrop.hidden) close();
  });
})();
