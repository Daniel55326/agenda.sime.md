# Agenda Electronică – clonă (mobile first)

## Rulare locală (simplu)
```bash
python -m venv .venv
source .venv/bin/activate   # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
python app.py
```
Apoi deschizi: http://127.0.0.1:5000

## Deploy pe Render (Python)
1) Pui proiectul pe GitHub
2) În Render: New + -> Web Service -> repo
3) Build: `pip install -r requirements.txt`
4) Start: `gunicorn app:app`

Dacă vrei, poți folosi fișierul `render.yaml` pentru deploy automat.
