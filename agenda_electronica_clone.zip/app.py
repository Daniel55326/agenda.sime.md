from flask import Flask, send_from_directory

app = Flask(__name__, static_folder="static", static_url_path="/static")

@app.get("/")
def home():
    return send_from_directory(".", "index.html")

@app.get("/app")
def app_page():
    return send_from_directory(".", "app.html")

@app.get("/index.html")
def index_page():
    return send_from_directory(".", "index.html")

@app.get("/app.html")
def app_html_page():
    return send_from_directory(".", "app.html")

if __name__ == "__main__":
    # Render foloseste PORT din env
    import os
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
